import os
import re
import json
import hmac
import hashlib
import secrets
import logging
import sqlite3
import smtplib
import ssl
from email.message import EmailMessage
from datetime import datetime, date
from urllib.parse import urlparse

import pandas as pd
import streamlit as st
from ddgs import DDGS

try:
    from google import genai
except Exception:
    genai = None

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("NEXORA_DB_PATH", os.path.join(APP_DIR, "nexora.db"))
LOG_PATH = os.path.join(APP_DIR, "nexora.log")

logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger("nexora")

st.set_page_config(page_title="NEXORA AI", page_icon="✦", layout="wide")

st.markdown("""
<style>
.stApp { background: #090b12; color: #eef0ff; }
[data-testid="stSidebar"] { background: #101321; }
.block-container { padding-top: 1.6rem; max-width: 1450px; }
h1,h2,h3 { color: #f3f2ff; }
.nexora-kicker { color:#a78bfa; letter-spacing:3px; font-size:12px; font-weight:700; }
.metric-card { background:linear-gradient(135deg,#171a2b,#111827); border:1px solid #292d45;
border-radius:14px; padding:16px; }
.small-muted { color:#9ca3af; font-size:13px; }
div.stButton > button { border-radius:10px; border:1px solid #6655c7; }
</style>
""", unsafe_allow_html=True)

def cfg(key, default=""):
    try:
        return st.secrets.get(key, os.environ.get(key, default))
    except Exception:
        return os.environ.get(key, default)

def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'client',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS campaigns(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            industry TEXT NOT NULL,
            location TEXT NOT NULL,
            ideal_customer TEXT NOT NULL,
            target_count INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'Created',
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS leads(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            business_name TEXT NOT NULL,
            website TEXT,
            email TEXT,
            phone TEXT,
            location TEXT,
            source_url TEXT NOT NULL,
            snippet TEXT,
            score INTEGER DEFAULT 0,
            category TEXT DEFAULT 'Unscored',
            reason TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            UNIQUE(user_id, source_url),
            FOREIGN KEY(campaign_id) REFERENCES campaigns(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS outreach(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lead_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            channel TEXT NOT NULL,
            draft TEXT NOT NULL,
            approved INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(lead_id) REFERENCES leads(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """)
        admin_email = cfg("ADMIN_EMAIL").strip().lower()
        admin_password = cfg("ADMIN_PASSWORD")
        if admin_email and admin_password and not c.execute(
            "SELECT id FROM users WHERE email=?", (admin_email,)
        ).fetchone():
            salt = secrets.token_hex(16)
            pwh = hash_password(admin_password, salt)
            c.execute(
                "INSERT INTO users(email,name,password_hash,salt,role,created_at) VALUES(?,?,?,?,?,?)",
                (admin_email, "NEXORA Admin", pwh, salt, "admin", datetime.utcnow().isoformat())
            )

def hash_password(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 240000).hex()

def valid_email(value):
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value or ""))

def register_user(name, email, password):
    if len(password) < 10:
        raise ValueError("Use a password with at least 10 characters.")
    salt = secrets.token_hex(16)
    with db() as c:
        c.execute(
            "INSERT INTO users(email,name,password_hash,salt,role,created_at) VALUES(?,?,?,?,?,?)",
            (email.lower().strip(), name.strip(), hash_password(password, salt), salt,
             "client", datetime.utcnow().isoformat())
        )

def login_user(email, password):
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE email=?", (email.lower().strip(),)).fetchone()
    if not row:
        return None
    candidate = hash_password(password, row["salt"])
    if hmac.compare_digest(candidate, row["password_hash"]):
        return dict(row)
    return None

def search_leads(industry, location, keywords, limit):
    """Search public search-result data only; does not crawl or scrape websites."""
    query = f"{industry} {keywords} businesses in {location} contact website"
    found, seen = [], set()
    with DDGS() as ddgs:
        results = ddgs.text(query, max_results=min(max(limit * 3, 10), 60))
        for item in results:
            title = (item.get("title") or "").strip()
            href = (item.get("href") or "").strip()
            body = (item.get("body") or "").strip()
            if not title or not href:
                continue
            parsed = urlparse(href)
            if parsed.scheme not in ("http", "https") or not parsed.netloc:
                continue
            clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
            if clean_url in seen:
                continue
            seen.add(clean_url)
            emails = re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", title + " " + body)
            phones = re.findall(r"(?:\+?\d[\d\s().-]{7,}\d)", title + " " + body)
            found.append({
                "business_name": title[:180],
                "website": f"{parsed.scheme}://{parsed.netloc}",
                "email": emails[0] if emails else "",
                "phone": phones[0].strip() if phones else "",
                "location": location,
                "source_url": href,
                "snippet": body[:1000],
            })
            if len(found) >= limit:
                break
    return found

def ai_qualify(leads, industry, ideal_customer):
    api_key = cfg("GEMINI_API_KEY")
    if not api_key or genai is None:
        return None, "Gemini is not configured. Add GEMINI_API_KEY to Streamlit Secrets."
    client = genai.Client(api_key=api_key)
    results = []
    for lead in leads:
        prompt = f"""Assess this B2B prospect for a lead-generation campaign.
Target industry: {industry}
Ideal customer profile: {ideal_customer}
Prospect: {json.dumps(lead, ensure_ascii=False)}
Return ONLY JSON with integer score 0-100, category Hot/Warm/Cold,
and a concise evidence-based reason. Do not infer facts absent from the data."""
        try:
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt,
                config={"response_mime_type": "application/json"}
            )
            data = json.loads(response.text)
            score = max(0, min(100, int(data.get("score", 0))))
            category = data.get("category", "Cold")
            if category not in ("Hot", "Warm", "Cold"):
                category = "Cold"
            results.append((score, category, str(data.get("reason", ""))[:500]))
        except Exception as e:
            logger.exception("Gemini qualification failed")
            results.append((0, "Unscored", "AI qualification unavailable; review manually."))
    return results, None

def send_email(to_addr, subject, body):
    host, port = cfg("SMTP_HOST"), int(cfg("SMTP_PORT", "587"))
    username, password = cfg("SMTP_USERNAME"), cfg("SMTP_PASSWORD")
    sender = cfg("SMTP_FROM", username)
    if not all([host, username, password, sender, to_addr]):
        raise ValueError("Email is not configured. Add SMTP settings in Streamlit Secrets.")
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, sender, to_addr
    msg.set_content(body)
    context = ssl.create_default_context()
    with smtplib.SMTP(host, port, timeout=20) as server:
        server.starttls(context=context)
        server.login(username, password)
        server.send_message(msg)

def get_campaigns(user):
    with db() as c:
        if user["role"] == "admin":
            rows = c.execute("""SELECT campaigns.*, users.email AS owner_email
                FROM campaigns JOIN users ON users.id=campaigns.user_id
                ORDER BY campaigns.id DESC""").fetchall()
        else:
            rows = c.execute("SELECT * FROM campaigns WHERE user_id=? ORDER BY id DESC", (user["id"],)).fetchall()
    return [dict(x) for x in rows]

def get_leads(user, campaign_id=None):
    with db() as c:
        if user["role"] == "admin":
            if campaign_id:
                rows = c.execute("SELECT * FROM leads WHERE campaign_id=? ORDER BY id DESC", (campaign_id,)).fetchall()
            else:
                rows = c.execute("SELECT * FROM leads ORDER BY id DESC").fetchall()
        else:
            if campaign_id:
                rows = c.execute("SELECT * FROM leads WHERE user_id=? AND campaign_id=? ORDER BY id DESC",
                                 (user["id"], campaign_id)).fetchall()
            else:
                rows = c.execute("SELECT * FROM leads WHERE user_id=? ORDER BY id DESC", (user["id"],)).fetchall()
    return [dict(x) for x in rows]

def make_outreach(lead, channel, client_name):
    api_key = cfg("GEMINI_API_KEY")
    if not api_key or genai is None:
        raise ValueError("Configure GEMINI_API_KEY to generate personalised drafts.")
    client = genai.Client(api_key=api_key)
    prompt = f"""Write one concise, respectful first-contact {channel} draft from {client_name}.
Use only these prospect facts: {json.dumps(lead, ensure_ascii=False)}.
Do not claim a relationship or invent personal details. Avoid pressure, deception,
or unsupported claims. Include a clear opt-out-friendly tone. Return only the draft."""
    response = client.models.generate_content(model="gemini-2.5-flash", contents=prompt)
    return response.text.strip()

init_db()

if "user" not in st.session_state:
    st.session_state.user = None

def auth_screen():
    st.markdown('<div class="nexora-kicker">INTELLIGENT PROSPECTING PLATFORM</div>', unsafe_allow_html=True)
    st.title("✦ NEXORA AI")
    st.caption("Find better-fit business prospects. Qualify with AI. Keep outreach human-approved.")
    tab1, tab2 = st.tabs(["Sign in", "Create client account"])
    with tab1:
        with st.form("login"):
            email = st.text_input("Email")
            password = st.text_input("Password", type="password")
            ok = st.form_submit_button("Sign in", use_container_width=True)
        if ok:
            user = login_user(email, password)
            if user:
                st.session_state.user = user
                st.rerun()
            else:
                st.error("Invalid email or password.")
    with tab2:
        with st.form("register"):
            name = st.text_input("Your name")
            email = st.text_input("Business email", key="reg_email")
            password = st.text_input("Create password (10+ characters)", type="password", key="reg_pw")
            confirm = st.text_input("Confirm password", type="password")
            ok = st.form_submit_button("Create account", use_container_width=True)
        if ok:
            try:
                if not name.strip() or not valid_email(email):
                    raise ValueError("Enter your name and a valid email address.")
                if password != confirm:
                    raise ValueError("Passwords do not match.")
                register_user(name, email, password)
                st.success("Account created. Sign in to continue.")
            except sqlite3.IntegrityError:
                st.error("An account with this email already exists.")
            except Exception as e:
                st.error(str(e))
    st.info("For a public launch, add HTTPS hosting, database backups, rate limiting, and a production authentication provider. SQLite is intended for this small MVP.")

if not st.session_state.user:
    auth_screen()
    st.stop()

user = st.session_state.user
with st.sidebar:
    st.markdown("## ✦ NEXORA AI")
    st.caption(f"{user['name']} · {user['role'].title()}")
    page = st.radio("WORKSPACE", [
        "Overview", "Find Leads", "AI Lead Qualification", "Campaign Manager",
        "Outreach Studio", "Email Alerts", "Client Management", "Analytics", "Settings"
    ])
    if st.button("Sign out", use_container_width=True):
        st.session_state.user = None
        st.rerun()

campaigns = get_campaigns(user)
all_leads = get_leads(user)
st.markdown('<div class="nexora-kicker">NEXORA INTELLIGENCE / WORKSPACE</div>', unsafe_allow_html=True)

if page == "Overview":
    st.title("Overview")
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Campaigns", len(campaigns))
    c2.metric("Prospects found", len(all_leads))
    c3.metric("Hot leads", sum(x["category"]=="Hot" for x in all_leads))
    c4.metric("Outreach drafts", sum(1 for x in []))
    if all_leads:
        df = pd.DataFrame(all_leads)
        st.subheader("Lead pipeline")
        st.bar_chart(df["category"].value_counts())
        st.dataframe(df[["business_name","industry"] if "industry" in df.columns else
                         ["business_name","location","score","category","email"]], use_container_width=True)
    else:
        st.info("Create a campaign and run Find Leads to populate your workspace.")
    st.subheader("Quick start")
    st.write("1. Create a campaign → 2. Discover prospects → 3. Qualify → 4. Review outreach drafts → 5. Export your report.")

elif page == "Campaign Manager":
    st.title("Campaign Manager")
    with st.form("new_campaign"):
        name = st.text_input("Campaign name", placeholder="Kolkata fitness studio prospects")
        industry = st.selectbox("Target industry", ["Real estate","Digital marketing","Gyms and fitness","Coaching institutes","Beauty and cosmetics","Web development","Local services","Other"])
        location = st.text_input("Target location", placeholder="Kolkata, India")
        ideal = st.text_area("Ideal customer profile", placeholder="Independent businesses with an active website...")
        target = st.number_input("Maximum prospects to discover", min_value=1, max_value=50, value=10)
        submitted = st.form_submit_button("Create campaign")
    if submitted:
        if not name.strip() or not location.strip() or not ideal.strip():
            st.error("Complete all campaign fields.")
        else:
            with db() as c:
                c.execute("""INSERT INTO campaigns(user_id,name,industry,location,ideal_customer,target_count,created_at)
                    VALUES(?,?,?,?,?,?,?)""",
                    (user["id"],name.strip(),industry,location.strip(),ideal.strip(),int(target),datetime.utcnow().isoformat()))
            st.success("Campaign created.")
            st.rerun()
    st.subheader("Your campaigns")
    if campaigns:
        st.dataframe(pd.DataFrame(campaigns), use_container_width=True)
    else:
        st.info("No campaigns yet.")

elif page == "Find Leads":
    st.title("Find Leads")
    if not campaigns:
        st.warning("Create a campaign first.")
    else:
        selected = st.selectbox("Select campaign", campaigns, format_func=lambda x: f"#{x['id']} · {x['name']}")
        st.caption("Discovery uses search-result listings only. Search engines may return incomplete or inaccurate details; verify each prospect before contacting.")
        if st.button("Discover prospects", type="primary"):
            try:
                with st.spinner("Searching public business listings..."):
                    prospects = search_leads(selected["industry"], selected["location"], selected["ideal_customer"], selected["target_count"])
                saved = 0
                with db() as c:
                    for p in prospects:
                        try:
                            c.execute("""INSERT INTO leads(campaign_id,user_id,business_name,website,email,phone,location,
                                source_url,snippet,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                                (selected["id"],user["id"],p["business_name"],p["website"],p["email"],p["phone"],
                                 p["location"],p["source_url"],p["snippet"],datetime.utcnow().isoformat()))
                            saved += 1
                        except sqlite3.IntegrityError:
                            pass
                    c.execute("UPDATE campaigns SET status='Discovery complete' WHERE id=?", (selected["id"],))
                st.success(f"Found {len(prospects)} search results; saved {saved} new prospects.")
                st.rerun()
            except Exception as e:
                logger.exception("Lead discovery failed")
                st.error(f"Search failed: {e}")
        data = get_leads(user, selected["id"])
        if data:
            st.dataframe(pd.DataFrame(data), use_container_width=True, column_config={
                "source_url": st.column_config.LinkColumn("Source"),
                "website": st.column_config.LinkColumn("Website")
            })

elif page == "AI Lead Qualification":
    st.title("AI Lead Qualification")
    if not campaigns:
        st.info("Create a campaign first.")
    else:
        selected = st.selectbox("Campaign", campaigns, format_func=lambda x: f"#{x['id']} · {x['name']}")
        data = get_leads(user, selected["id"])
        if not data:
            st.info("Discover prospects first.")
        elif st.button("Qualify unscored prospects with Gemini", type="primary"):
            with st.spinner("Evaluating prospect fit..."):
                pending = [x for x in data if x["category"] in ("Unscored","")]
                scored, error = ai_qualify(pending, selected["industry"], selected["ideal_customer"])
            if error:
                st.error(error)
            else:
                with db() as c:
                    for lead, result in zip(pending, scored):
                        score, category, reason = result
                        c.execute("UPDATE leads SET score=?,category=?,reason=? WHERE id=? AND user_id=?",
                                  (score,category,reason,lead["id"],user["id"]))
                st.success(f"Qualified {len(scored)} prospects.")
                st.rerun()
        data = get_leads(user, selected["id"])
        if data:
            st.dataframe(pd.DataFrame(data)[["business_name","score","category","reason","email","source_url"]],
                         use_container_width=True, column_config={"source_url":st.column_config.LinkColumn("Source")})

elif page == "Outreach Studio":
    st.title("Outreach Studio")
    data = get_leads(user)
    if not data:
        st.info("Discover prospects first.")
    else:
        lead = st.selectbox("Prospect", data, format_func=lambda x: f"{x['business_name']} · {x['category']}")
        channel = st.selectbox("Draft channel", ["Email","Instagram DM","LinkedIn message"])
        if st.button("Generate personalised draft"):
            try:
                draft = make_outreach(lead, channel, user["name"])
                with db() as c:
                    c.execute("INSERT INTO outreach(lead_id,user_id,channel,draft,created_at) VALUES(?,?,?,?,?)",
                              (lead["id"],user["id"],channel,draft,datetime.utcnow().isoformat()))
                st.session_state.latest_draft = draft
            except Exception as e:
                st.error(str(e))
        if st.session_state.get("latest_draft"):
            st.text_area("Review and edit before sending", value=st.session_state.latest_draft, height=220)
            st.warning("This app creates drafts only. It does not send cold outreach automatically.")

elif page == "Email Alerts":
    st.title("Email Alerts")
    st.write("Send a report of qualified leads to the signed-in account email.")
    if st.button("Send qualified-lead report"):
        qualified = [x for x in all_leads if x["category"] in ("Hot","Warm")]
        if not qualified:
            st.warning("No Hot or Warm leads are available yet.")
        else:
            lines = ["NEXORA AI — Qualified Lead Report",""]
            for x in qualified:
                lines += [f"Business: {x['business_name']}",f"Score: {x['score']} ({x['category']})",
                          f"Email: {x['email'] or 'Not found'}",f"Website: {x['website'] or 'Not found'}",
                          f"Source: {x['source_url']}",""]
            try:
                send_email(user["email"], f"NEXORA AI report — {len(qualified)} leads", "\n".join(lines))
                st.success(f"Report sent to {user['email']}.")
            except Exception as e:
                logger.exception("Email report failed")
                st.error(str(e))
    st.caption("Configure SMTP credentials in Streamlit Secrets. Email alerts are user-triggered in this MVP; scheduled daily delivery requires a separate scheduler/worker.")

elif page == "Client Management":
    st.title("Client Management")
    if user["role"] != "admin":
        st.info("This area is available to the agency administrator.")
    else:
        with db() as c:
            clients = c.execute("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC").fetchall()
            camp_count = c.execute("SELECT COUNT(*) n FROM campaigns").fetchone()["n"]
            lead_count = c.execute("SELECT COUNT(*) n FROM leads").fetchone()["n"]
        st.metric("Total campaigns", camp_count)
        st.metric("Total prospects", lead_count)
        st.dataframe(pd.DataFrame([dict(x) for x in clients]), use_container_width=True)

elif page == "Analytics":
    st.title("Analytics")
    if all_leads:
        df = pd.DataFrame(all_leads)
        a,b = st.columns(2)
        with a:
            st.subheader("Lead categories")
            st.bar_chart(df["category"].value_counts())
        with b:
            st.subheader("Lead scores")
            st.histogram if False else None
            st.bar_chart(df.groupby("category")["score"].mean())
        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button("Download all leads as CSV", csv, "nexora_leads.csv", "text/csv")
    else:
        st.info("Analytics will appear after you discover prospects.")

elif page == "Settings":
    st.title("Settings")
    st.write("Account")
    st.code(f"Name: {user['name']}\\nEmail: {user['email']}\\nRole: {user['role']}")
    st.subheader("Configuration status")
    for key, label in [("GEMINI_API_KEY","Gemini AI"),("SMTP_HOST","SMTP host"),("SMTP_USERNAME","SMTP username"),("SMTP_PASSWORD","SMTP password")]:
        st.write(("✅ " if cfg(key) else "⚪ ") + label)
    st.warning("Never commit secrets.toml, API keys, SMTP passwords, or the SQLite database to a public GitHub repository.")
    st.caption("SQLite is suitable for a prototype. Streamlit Community Cloud local storage may not be durable across app restarts/redeployments. Use managed PostgreSQL for production.")
