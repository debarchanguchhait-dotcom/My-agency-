# NEXORA AI — Lead Generation MVP

A Streamlit MVP for discovering public business search listings, AI-assisted prospect qualification, human-reviewed outreach drafts, CSV exports, and user-triggered email reports.

## What works in this MVP
- Client account registration and sign-in (PBKDF2 password hashing).
- Admin account bootstrapped from `ADMIN_EMAIL` and `ADMIN_PASSWORD` secrets.
- Campaign creation and per-client lead separation.
- Business prospect discovery from DuckDuckGo search result metadata using `ddgs`.
- Deduplication by user and source URL.
- Optional Gemini scoring and outreach-draft generation.
- CSV export and manually triggered email report via SMTP.

## Important limitations
- Search results are not a verified lead database. Verify every result and contact detail.
- The app does not crawl websites, bypass access controls, scrape private data, or automatically send outreach.
- Daily scheduled email delivery, payment processing, subscription billing, and full production-grade authentication are not implemented.
- SQLite is for local prototyping. Streamlit Community Cloud's local filesystem should not be treated as durable storage. Use managed PostgreSQL before real multi-client production.
- Do not use this MVP to send unsolicited bulk messages. Follow applicable privacy, platform, and anti-spam rules.

## Run locally
1. Install Python 3.10+.
2. Create and activate a virtual environment.
3. Install dependencies:

   `pip install -r requirements.txt`

4. Copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml`.
5. Add your own Gemini key, admin credentials, and optional SMTP credentials.
6. Start:

   `streamlit run app.py`

## Deploy from GitHub to Streamlit Community Cloud
1. Create a GitHub repository and upload `app.py`, `requirements.txt`, `.gitignore`, and `.streamlit/config.toml`.
2. Do **not** upload `.streamlit/secrets.toml`, `nexora.db`, or `nexora.log`.
3. In Streamlit Community Cloud, create an app from your repository and select `app.py`.
4. Open app settings → Secrets and paste the contents of your private secrets file, replacing all example values.
5. Deploy and test registration, campaign creation, discovery, qualification, and email configuration.

## Secrets
Use `.streamlit/secrets.toml` locally or Streamlit Cloud's Secrets panel. Never put API keys or passwords in source code or GitHub.

## Admin setup
On first launch, if `ADMIN_EMAIL` and `ADMIN_PASSWORD` are configured, the app creates that admin account. Set a long unique password before deployment. If you change the secret later, the existing account password is not automatically changed.

## Gmail SMTP
For Gmail, enable 2-Step Verification and create an App Password in your Google Account security settings. Use that App Password as `SMTP_PASSWORD`, not your normal Gmail password. Availability and account requirements may vary.

## Suggested test
- Create a client account.
- Create a campaign for a known industry and city.
- Run discovery and inspect each source link.
- Run Gemini qualification if configured.
- Generate an outreach draft and edit it.
- Test CSV export.
- Configure SMTP and send a report to your own account.

## Production checklist
Before onboarding paying clients, move to managed PostgreSQL, add email verification and password reset, add rate limiting and abuse controls, implement tenant isolation tests, use a secrets manager, add backups and monitoring, and review privacy/legal requirements with a qualified adult/professional.
